const crypto = require('crypto');
const { Pool } = require('pg');
const seed = require('../products_catalog_seed.json');

// Único e-mail autorizado a acessar o Painel do Dono.
const OWNER_EMAIL_FIXED = 'dina184513@gmail.com';
const normalizeEmail = email => String(email || '').trim().toLowerCase();
const isOwnerEmail = email => normalizeEmail(email) === OWNER_EMAIL_FIXED;

const pool = process.env.POSTGRES_URL || process.env.DATABASE_URL || process.env.POSTGRES_PRISMA_URL
  ? new Pool({ connectionString: process.env.POSTGRES_URL || process.env.DATABASE_URL || process.env.POSTGRES_PRISMA_URL, max: 2, ssl: { rejectUnauthorized: false } })
  : null;

let schemaPromise;
const json = (res, status, body) => { res.status(status).setHeader('Content-Type','application/json; charset=utf-8'); return res.end(JSON.stringify(body)); };
const ok = (res, body) => json(res, 200, body);
const fail = (res, status, message) => json(res, status, { error: message });
const body = async req => { if (req.body && typeof req.body === 'object') return req.body; let raw=''; for await (const c of req) raw += c; try{return raw?JSON.parse(raw):{};}catch{return{};} };
const routeOf = req => {
  const q = String(req.query?.route || '').replace(/^\//,'');
  if (q) return q;
  const p = new URL(req.url || '/', 'http://localhost').pathname.replace(/^\//,'');
  if (p.startsWith('api/')) return p.slice(4);
  return p;
};
const baseUrl = req => (process.env.PUBLIC_BASE_URL || `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers.host}`).replace(/\/$/,'');

function signToken(payload){
  const secret=process.env.SESSION_SECRET;
  if(!secret) throw new Error('SESSION_SECRET não configurado na Vercel.');
  const data=Buffer.from(JSON.stringify({...payload,exp:Date.now()+1000*60*60*24*30})).toString('base64url');
  const sig=crypto.createHmac('sha256',secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}
function verifyToken(token){
  if(!token || !process.env.SESSION_SECRET) return null;
  const [data,sig]=String(token).split('.'); if(!data||!sig) return null;
  const expected=crypto.createHmac('sha256',process.env.SESSION_SECRET).update(data).digest('base64url');
  if(!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) return null;
  try{const p=JSON.parse(Buffer.from(data,'base64url').toString()); return p.exp>Date.now()?p:null;}catch{return null;}
}
function auth(req){
  const h=String(req.headers.authorization||'');
  const bearer=h.startsWith('Bearer ')?h.slice(7):'';
  return verifyToken(bearer) || verifyToken((req.headers.cookie||'').match(/kaneki_session=([^;]+)/)?.[1]);
}
function setSession(res, token){res.setHeader('Set-Cookie',`kaneki_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`);}

async function db(){
  if(!pool) throw new Error('PostgreSQL não configurado. Crie um banco PostgreSQL e adicione POSTGRES_URL nas Environment Variables da Vercel.');
  if(!schemaPromise) schemaPromise=(async()=>{
    await pool.query(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,phone TEXT DEFAULT '',password_hash TEXT,role TEXT NOT NULL DEFAULT 'customer',provider TEXT NOT NULL DEFAULT 'password',avatar_url TEXT DEFAULT '',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS carts (user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,cart JSONB NOT NULL DEFAULT '{}'::jsonb,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS products (product_id TEXT PRIMARY KEY,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',price NUMERIC NOT NULL,old_price NUMERIC NOT NULL DEFAULT 0,stock TEXT NOT NULL DEFAULT '0',image TEXT NOT NULL DEFAULT '',catalog TEXT NOT NULL DEFAULT 'produtos',active BOOLEAN NOT NULL DEFAULT TRUE,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS orders (id BIGSERIAL PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE SET NULL,order_key TEXT UNIQUE NOT NULL,items JSONB NOT NULL,total NUMERIC NOT NULL,name TEXT,email TEXT,phone TEXT,status TEXT NOT NULL DEFAULT 'pending',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS tickets (id BIGSERIAL PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,order_id BIGINT REFERENCES orders(id) ON DELETE CASCADE,subject TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS ticket_messages (id BIGSERIAL PRIMARY KEY,ticket_id BIGINT REFERENCES tickets(id) ON DELETE CASCADE,sender_role TEXT NOT NULL,name TEXT NOT NULL,message TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS logs (id BIGSERIAL PRIMARY KEY,action TEXT NOT NULL,email TEXT,at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS chat_messages (id BIGSERIAL PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE SET NULL,name TEXT NOT NULL,message TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS site_settings (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '');
      CREATE TABLE IF NOT EXISTS reviews (id BIGSERIAL PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE SET NULL,order_id BIGINT REFERENCES orders(id) ON DELETE SET NULL,rating INT NOT NULL CHECK(rating BETWEEN 1 AND 5),message TEXT NOT NULL,product_text TEXT NOT NULL DEFAULT '',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),UNIQUE(user_id,order_id));`);
    await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''");
    await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS provider TEXT NOT NULL DEFAULT 'password'");
    await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT NOT NULL DEFAULT ''");
    const defaults={
      siteName:'KANEKI STORE', logoUrl:'images/kaneki-logo.png', backgroundImageUrl:'images/site-background-lilies.png', backgroundOpacity:'0.6', heroBackgroundUrl:'', heroMediaUrl:'', heroMediaType:'none', heroTitle:'𝕮𝖔𝖒𝖕𝖗𝖊 𝖋𝖆𝖈𝖎𝖑, 𝖗𝖆𝖕𝖎𝖉𝖔 𝖊 𝖘𝖊𝖌𝖚𝖗𝖔!', heroAccent:'', heroDescription:'Contas, gamepasses e frutas para Blox Fruits, com pagamento seguro via Pix e informações de entrega antes da compra.', heroButton:'Ver catálogo', heroBadge1:'✓ LOJA OFICIAL', heroBadge2:'⚡ ENTREGA AUTOMÁTICA', tutorialTitle:'Clique aqui', tutorialSubtitle:'Assista como comprar na KANEKI STORE', tutorialVideoUrl:'https://youtu.be/7aMOurgDB-o?is=XG9LU3hscFktyKOs', discordUrl:'https://discord.com/', supportUrl:'', whatsappUrl:'', footerText:'© 2026 KANEKI STORE. Todos os direitos reservados.', categories_json:JSON.stringify([{id:'produtos',title:'Frutas permanentes',text:'Aqui você vai encontrar as melhores frutas permanentes',button:'Ver produtos',image:'',color:'#e21b23',active:true},{id:'skins',title:'Skins',text:'Aqui você vai encontrar as melhores skins de frutas',button:'Ver produtos',image:'',color:'#e21b23',active:true},{id:'frutasfisicas',title:'Frutas físicas',text:'Aqui você vai encontrar as melhores frutas físicas',button:'Ver produtos',image:'',color:'#e21b23',active:true},{id:'gamepass',title:'Game Pass',text:'Aqui você vai encontrar os melhores Game Pass',button:'Ver produtos',image:'',color:'#e21b23',active:true},{id:'gachabox',title:'Gacha Box',text:'Aqui você vai encontrar os melhores itens da Gacha Box',button:'Ver produtos',image:'',color:'#e21b23',active:true}]), primaryColor:'#e21b23', primaryDark:'#b91c1c', backgroundColor:'#070707', surfaceColor:'#ffffff', cardColor:'#111111', textColor:'#111111', mutedColor:'#6b6b76', accentText:'#ffffff'
    };
    for(const [k,v] of Object.entries(defaults)){await pool.query('INSERT INTO site_settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO NOTHING',[k,v]);}
    const count=await pool.query('SELECT COUNT(*)::int AS n FROM products');
    if(count.rows[0].n===0){for(const [id,p] of Object.entries(seed)){await pool.query(`INSERT INTO products(product_id,name,description,price,old_price,stock,image,catalog) VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING`,[id,p.name,p.description||'',p.price,p.old,String(p.stock),p.image||'',p.catalog||'produtos']);}}
  })().catch(e=>{schemaPromise=null;throw e;});
  await schemaPromise; return pool;
}

function hashPassword(password){const salt=crypto.randomBytes(16).toString('hex');const hash=crypto.scryptSync(String(password),salt,64).toString('hex');return `${salt}:${hash}`;}
function checkPassword(password,stored){try{const [salt,hash]=String(stored||'').split(':');const got=crypto.scryptSync(String(password),salt,64).toString('hex');return crypto.timingSafeEqual(Buffer.from(got,'hex'),Buffer.from(hash,'hex'));}catch{return false;}}
function publicUser(r){return {id:r.id,email:r.email,name:r.name,phone:r.phone||'',role:r.role};}
async function log(action,email=''){await pool.query('INSERT INTO logs(action,email) VALUES($1,$2)',[action,email||null]).catch(()=>{});}

async function catalog(res){
  if(!pool) return ok(res,{products:Object.entries(seed).map(([product_id,p])=>({product_id,...p,old:p.old,image:p.image||'',catalog:p.catalog||'produtos'}))});
  await db(); const q=await pool.query('SELECT product_id,name,description,price,old_price AS old,stock,image,catalog FROM products WHERE active=true ORDER BY product_id'); const rows=q.rows.map(p=>({...p,image:(String(p.image||'').startsWith('images/')?'':p.image)})); return ok(res,{products:rows});
}

async function me(req,res){const t=auth(req); if(!t) return ok(res,{user:null,cart:{}}); await db(); const u=await pool.query('SELECT * FROM users WHERE id=$1',[t.id]); if(!u.rowCount) return ok(res,{user:null,cart:{}}); const c=await pool.query('SELECT cart FROM carts WHERE user_id=$1',[t.id]); return ok(res,{user:publicUser(u.rows[0]),cart:c.rowCount?c.rows[0].cart:{}});}

async function loginRegister(req,res,isRegister){
  await db(); const b=await body(req); const email=String(b.email||'').trim().toLowerCase(), password=String(b.password||'');
  if(!email||!password) return fail(res,400,'Informe e-mail e senha.');
  const existing=await pool.query('SELECT * FROM users WHERE email=$1',[email]); let u;
  if(isRegister){
    if(existing.rowCount) return fail(res,409,'Este e-mail já está cadastrado.');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail(res,400,'E-mail inválido.');
    const owner=isOwnerEmail(email);
    if(owner && process.env.OWNER_PASSWORD && password!==process.env.OWNER_PASSWORD) return fail(res,403,'Para criar a conta do dono, use a senha configurada em OWNER_PASSWORD.');
    const id=crypto.randomUUID(); const role=owner?'owner':'customer';
    const r=await pool.query('INSERT INTO users(id,email,name,phone,password_hash,role,provider) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[id,email,String(b.name||email.split('@')[0]).slice(0,100),String(b.phone||'').slice(0,40),hashPassword(password),role,'password']); u=r.rows[0]; await log('register',email);
  }else{
    if(!existing.rowCount || !checkPassword(password,existing.rows[0].password_hash)) return fail(res,401,'E-mail ou senha incorretos.');
    u=existing.rows[0]; await log('login',email);
  }
  const token=signToken({id:u.id,email:u.email,role:u.role,provider:u.provider||'password'}); setSession(res,token); const c=await pool.query('SELECT cart FROM carts WHERE user_id=$1',[u.id]); return ok(res,{user:publicUser(u),token,cart:c.rowCount?c.rows[0].cart:{}});
}

async function cart(req,res){const t=auth(req);if(!t)return fail(res,401,'Faça login para salvar o carrinho.');await db();const b=await body(req);await pool.query(`INSERT INTO carts(user_id,cart,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(user_id) DO UPDATE SET cart=EXCLUDED.cart,updated_at=NOW()`,[t.id,JSON.stringify(b.cart||{})]);return ok(res,{ok:true});}

async function orders(req,res){const t=auth(req);if(!t)return fail(res,401,'Faça login para registrar o pedido.');await db();const b=await body(req);const items=Array.isArray(b.items)?b.items:[];if(!items.length)return fail(res,400,'Carrinho vazio.');const orderKey=String(b.orderKey||crypto.randomUUID());const r=await pool.query(`INSERT INTO orders(user_id,order_key,items,total,name,email,phone) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[t.id,orderKey,JSON.stringify(items),Number(b.total||0),String(b.name||t.name||''),String(b.email||t.email||''),String(b.phone||'')]);await log('order',t.email);return ok(res,{orderId:r.rows[0].id,orderKey});}

async function myOrders(req,res){const t=auth(req);if(!t)return fail(res,401,'Faça login primeiro.');await db();const r=await pool.query('SELECT id,order_key,items,total,name,email,phone,status,created_at AS "createdAt" FROM orders WHERE user_id=$1 ORDER BY created_at DESC',[t.id]);return ok(res,{orders:r.rows});}

async function tickets(req,res){const t=auth(req);if(!t)return fail(res,401,'Faça login primeiro.');await db();if(req.method==='POST'){
  const b=await body(req);const o=await pool.query('SELECT * FROM orders WHERE id=$1 AND user_id=$2',[b.orderId,t.id]);if(!o.rowCount)return fail(res,404,'Compra não encontrada.');
  const r=await pool.query('INSERT INTO tickets(user_id,order_id,subject) VALUES($1,$2,$3) RETURNING id',[t.id,b.orderId,String(b.subject||'Atendimento')]);await pool.query('INSERT INTO ticket_messages(ticket_id,sender_role,name,message) VALUES($1,$2,$3,$4)',[r.rows[0].id,'customer',t.email,String(b.message||'')]);
 }
 const isOwner=t.role==='owner'; const q=isOwner?await pool.query(`SELECT t.*,o.order_key,o.name AS customer_name,o.email FROM tickets t LEFT JOIN orders o ON o.id=t.order_id ORDER BY t.updated_at DESC`):await pool.query(`SELECT t.*,o.order_key,o.name AS customer_name,o.email FROM tickets t LEFT JOIN orders o ON o.id=t.order_id WHERE t.user_id=$1 ORDER BY t.updated_at DESC`,[t.id]);
 const out=[];for(const row of q.rows){const m=await pool.query('SELECT sender_role,name,message,created_at AS "createdAt" FROM ticket_messages WHERE ticket_id=$1 ORDER BY created_at',[row.id]);out.push({...row,messages:m.rows});}return ok(res,{tickets:out});}

async function ticketReply(req,res){const t=auth(req);if(!t)return fail(res,401,'Faça login primeiro.');await db();const b=await body(req);const q=['owner','admin'].includes(t.role)?await pool.query('SELECT * FROM tickets WHERE id=$1',[b.ticketId]):await pool.query('SELECT * FROM tickets WHERE id=$1 AND user_id=$2',[b.ticketId,t.id]);if(!q.rowCount)return fail(res,404,'Ticket não encontrado.');const role=t.role==='owner'?'owner':(t.role==='admin'?'admin':'customer');await pool.query('INSERT INTO ticket_messages(ticket_id,sender_role,name,message) VALUES($1,$2,$3,$4)',[b.ticketId,role,t.name||t.email,String(b.message||'')]);await pool.query('UPDATE tickets SET status=COALESCE($2,status),updated_at=NOW() WHERE id=$1',[b.ticketId,b.status||null]);return ok(res,{ok:true});}

async function chatGeneral(req,res){
  const t=auth(req);
  await db();
  if(req.method==='POST'){
    if(!t)return fail(res,401,'Faça login para enviar mensagens no chat.');
    const b=await body(req); const message=String(b.message||'').trim();
    if(!message)return fail(res,400,'Digite uma mensagem.');
    if(message.length>500)return fail(res,400,'A mensagem pode ter até 500 caracteres.');
    await pool.query('INSERT INTO chat_messages(user_id,name,message) VALUES($1,$2,$3)',[t.id,String(t.name||t.email).slice(0,100),message]);
    return ok(res,{ok:true});
  }
  const q=await pool.query(`SELECT c.id,c.name,c.message,c.created_at AS "createdAt",u.role FROM chat_messages c LEFT JOIN users u ON u.id=c.user_id ORDER BY c.id DESC LIMIT 80`);
  return ok(res,{messages:q.rows.reverse()});
}

async function adminTickets(req,res){
  const t=auth(req); if(!t || !['owner','admin'].includes(t.role)) return fail(res,403,'Acesso restrito aos administradores.');
  await db();
  const q=await pool.query(`SELECT t.*,o.order_key,o.name AS customer_name,o.email FROM tickets t LEFT JOIN orders o ON o.id=t.order_id ORDER BY t.updated_at DESC`);
  const out=[]; for(const row of q.rows){const m=await pool.query('SELECT sender_role,name,message,created_at AS "createdAt" FROM ticket_messages WHERE ticket_id=$1 ORDER BY created_at',[row.id]);out.push({...row,messages:m.rows});}
  return ok(res,{tickets:out});
}

async function adminRoles(req,res){
  const t=auth(req); if(!t || !isOwnerEmail(t.email) || t.role!=='owner' || t.provider!=='google') return fail(res,403,'Somente o dono pode gerenciar administradores.');
  await db(); const b=await body(req); const userId=String(b.userId||''); const action=String(b.action||'');
  if(!userId || !['grant','revoke'].includes(action)) return fail(res,400,'Dados inválidos.');
  const q=await pool.query('SELECT * FROM users WHERE id=$1',[userId]); if(!q.rowCount)return fail(res,404,'Usuário não encontrado.');
  if(isOwnerEmail(q.rows[0].email)) return fail(res,400,'O dono não pode perder o próprio acesso.');
  const role=action==='grant'?'admin':'customer';
  const u=await pool.query('UPDATE users SET role=$1 WHERE id=$2 RETURNING id,email,name,role',[role,userId]);
  await log(action==='grant'?'admin-grant':'admin-revoke',q.rows[0].email);
  return ok(res,{user:u.rows[0]});
}


async function reviews(req,res){
  await db();
  if(req.method==='GET'){
    const q=await pool.query(`SELECT r.id,r.rating,r.message,r.product_text AS "productText",r.created_at AS "createdAt",COALESCE(u.name,'Cliente verificado') AS name,COALESCE(u.avatar_url,'') AS "avatarUrl" FROM reviews r LEFT JOIN users u ON u.id=r.user_id ORDER BY r.created_at DESC LIMIT 60`);
    return ok(res,{reviews:q.rows});
  }
  const t=auth(req); if(!t)return fail(res,401,'Faça login para avaliar uma compra.');
  const b=await body(req); const rating=Math.max(1,Math.min(5,Number(b.rating||0))); const message=String(b.message||'').trim();
  if(!rating||!message)return fail(res,400,'Informe a nota e a avaliação.'); if(message.length>300)return fail(res,400,'A avaliação pode ter até 300 caracteres.');
  const orderId=b.orderId?Number(b.orderId):null;
  let order;
  if(orderId){const q=await pool.query('SELECT * FROM orders WHERE id=$1 AND user_id=$2',[orderId,t.id]); if(!q.rowCount)return fail(res,404,'Pedido não encontrado.'); order=q.rows[0];}
  else {const q=await pool.query('SELECT * FROM orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1',[t.id]); if(!q.rowCount)return fail(res,400,'Faça uma compra antes de avaliar.'); order=q.rows[0];}
  const productText=(Array.isArray(order.items)?order.items:[]).map(i=>`${i.name||'Produto'}${i.qty>1?' × '+i.qty:''}`).join(', ').slice(0,220);
  const q=await pool.query(`INSERT INTO reviews(user_id,order_id,rating,message,product_text) VALUES($1,$2,$3,$4,$5) ON CONFLICT(user_id,order_id) DO UPDATE SET rating=EXCLUDED.rating,message=EXCLUDED.message,product_text=EXCLUDED.product_text RETURNING id`,[t.id,order.id,rating,message,productText]);
  await log('review',t.email); return ok(res,{ok:true,reviewId:q.rows[0].id});
}

async function robloxLookup(req,res){
  const username=String(req.query?.username||'').trim();
  if(!username)return fail(res,400,'Informe o usuário do Roblox.');
  if(username.length>40)return fail(res,400,'Usuário inválido.');
  try{
    const ur=await fetch('https://users.roblox.com/v1/usernames/users',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({usernames:[username],excludeBannedUsers:false})});
    const uraw=await ur.text(); let ud={}; try{ud=JSON.parse(uraw)}catch{return fail(res,502,'O Roblox retornou uma resposta inválida.')}
    if(!ur.ok)return fail(res,502,'O Roblox não respondeu.');
    const user=ud?.data?.[0]; if(!user)return fail(res,404,'Usuário do Roblox não encontrado.');
    const tr=await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${encodeURIComponent(user.id)}&size=150x150&format=Png&isCircular=false`,{headers:{Accept:'application/json'}});
    const traw=await tr.text(); let td={}; try{td=JSON.parse(traw)}catch{}
    const thumb=td?.data?.[0];
    return ok(res,{id:user.id,name:user.name,displayName:user.displayName,avatarUrl:thumb?.imageUrl||''});
  }catch(e){return fail(res,502,'Não foi possível consultar o Roblox agora.');}
}

async function siteSettings(res){
  if(!pool) return ok(res,{settings:{}});
  await db(); const q=await pool.query('SELECT key,value FROM site_settings'); const settings={}; for(const r of q.rows) settings[r.key]=r.value; return ok(res,{settings});
}
async function adminSettings(req,res){
  const t=auth(req); if(!t || !isOwnerEmail(t.email) || t.role!=='owner' || t.provider!=='google') return fail(res,403,'Acesso restrito: entre com Google usando dina184513@gmail.com.'); await db();
  const b=await body(req); const allowed=['siteName','logoUrl','backgroundImageUrl','backgroundOpacity','heroBackgroundUrl','heroMediaUrl','heroMediaType','heroTitle','heroAccent','heroDescription','heroButton','heroBadge1','heroBadge2','tutorialTitle','tutorialSubtitle','tutorialVideoUrl','discordUrl','supportUrl','whatsappUrl','footerText','categories_json','primaryColor','primaryDark','backgroundColor','surfaceColor','cardColor','textColor','mutedColor','accentText',...Object.keys(b||{}).filter(k=>k.startsWith('content_')||k.startsWith('visible_')||k.startsWith('link_')||k.startsWith('image_')||k.startsWith('button_'))];
  for(const key of allowed){ if(b[key]!==undefined) await pool.query('INSERT INTO site_settings(key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()',[key,String(b[key]??'')]); }
  await log('site-settings-update',t.email); return ok(res,{ok:true});
}
async function adminSummary(req,res){const t=auth(req);if(!t || !isOwnerEmail(t.email) || t.role!=='owner' || t.provider!=='google') return fail(res,403,'Acesso restrito: entre com Google usando dina184513@gmail.com.');await db();const [u,o,tic,p,l]=await Promise.all([pool.query('SELECT id,email,name,role,created_at AS "createdAt" FROM users ORDER BY created_at DESC'),pool.query('SELECT id,order_key,items,total,name,email,phone,status,created_at AS "createdAt" FROM orders ORDER BY created_at DESC'),pool.query('SELECT id,status FROM tickets ORDER BY updated_at DESC'),pool.query('SELECT product_id,name,description,price,old_price AS old,stock,image,catalog,active FROM products ORDER BY product_id'),pool.query('SELECT action,email,at FROM logs ORDER BY at DESC LIMIT 200')]);const sq=await pool.query('SELECT key,value FROM site_settings'); const settings={}; for(const r of sq.rows) settings[r.key]=r.value; return ok(res,{users:u.rows,orders:o.rows,tickets:tic.rows,products:p.rows,logs:l.rows,settings});}
async function adminProduct(req,res,del=false){const t=auth(req);if(!t || !isOwnerEmail(t.email) || t.role!=='owner' || t.provider!=='google') return fail(res,403,'Acesso restrito: entre com Google usando dina184513@gmail.com.');await db();const b=await body(req);if(del){await pool.query('UPDATE products SET active=false,updated_at=NOW() WHERE product_id=$1',[b.productId]);return ok(res,{ok:true});}await pool.query(`INSERT INTO products(product_id,name,description,price,old_price,stock,image,catalog,active,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW()) ON CONFLICT(product_id) DO UPDATE SET name=EXCLUDED.name,description=EXCLUDED.description,price=EXCLUDED.price,old_price=EXCLUDED.old_price,stock=EXCLUDED.stock,image=EXCLUDED.image,catalog=EXCLUDED.catalog,active=EXCLUDED.active,updated_at=NOW()`,[String(b.productId),String(b.name),String(b.description||''),Number(b.price||0),Number(b.old||0),String(b.stock),String(b.image||''),String(b.catalog||'produtos'),b.active!==false]);return ok(res,{ok:true});}

async function oauthStart(req,res,provider){const cfg=provider==='google'?{id:process.env.GOOGLE_CLIENT_ID,auth:'https://accounts.google.com/o/oauth2/v2/auth',scope:'openid email profile'}:{id:process.env.DISCORD_CLIENT_ID,auth:'https://discord.com/oauth2/authorize',scope:'identify email'};if(!cfg.id)return fail(res,500,`${provider.toUpperCase()}_CLIENT_ID não configurado na Vercel.`);if(!process.env.SESSION_SECRET)return fail(res,500,'SESSION_SECRET não configurado na Vercel.');const state=crypto.randomBytes(24).toString('hex');res.setHeader('Set-Cookie',`oauth_state=${state}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600`);const u=new URL(cfg.auth);u.searchParams.set('client_id',cfg.id);u.searchParams.set('redirect_uri',`${baseUrl(req)}/api/oauth/${provider}/callback`);u.searchParams.set('response_type','code');u.searchParams.set('scope',cfg.scope);u.searchParams.set('state',state);if(provider==='google')u.searchParams.set('access_type','online');return res.writeHead(302,{Location:u.toString()}).end();}
async function oauthCallback(req,res,provider){const q=req.query||{};const stateCookie=String(req.headers.cookie||'').match(/oauth_state=([^;]+)/)?.[1];if(!q.state||q.state!==stateCookie)return fail(res,400,'Estado OAuth inválido. Tente novamente.');const code=String(q.code||'');if(!code)return fail(res,400,'Código OAuth ausente.');const redirect=`${baseUrl(req)}/api/oauth/${provider}/callback`;
 let profile;
 if(provider==='google'){
  const tr=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code,client_id:process.env.GOOGLE_CLIENT_ID,client_secret:process.env.GOOGLE_CLIENT_SECRET,redirect_uri:redirect,grant_type:'authorization_code'})});const tok=await tr.json();if(!tr.ok)return fail(res,502,'Google recusou o login OAuth.');const pr=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${tok.access_token}`}});profile=await pr.json();
 }else{
  const tr=await fetch('https://discord.com/api/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code,client_id:process.env.DISCORD_CLIENT_ID,client_secret:process.env.DISCORD_CLIENT_SECRET,redirect_uri:redirect,grant_type:'authorization_code'})});const tok=await tr.json();if(!tr.ok)return fail(res,502,'Discord recusou o login OAuth.');const pr=await fetch('https://discord.com/api/users/@me',{headers:{Authorization:`Bearer ${tok.access_token}`}});profile=await pr.json();
 }
 const email=String(profile.email||'').toLowerCase();if(!email)return fail(res,400,'O provedor não retornou um e-mail.');await db();let u=await pool.query('SELECT * FROM users WHERE email=$1',[email]);if(!u.rowCount){const id=crypto.randomUUID();const owner=isOwnerEmail(email);u=await pool.query('INSERT INTO users(id,email,name,phone,role,provider,avatar_url) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[id,email,String(profile.name||profile.global_name||email.split('@')[0]).slice(0,100),'',owner?'owner':'customer','google',String(profile.picture||'')]);}else {
   if(provider==='google') u=await pool.query("UPDATE users SET provider='google', avatar_url=$2, name=COALESCE(NULLIF($3,''),name) WHERE id=$1 RETURNING *",[u.rows[0].id,String(profile.picture||''),String(profile.name||'')]);
   if(isOwnerEmail(email) && u.rows[0].role!=='owner') u=await pool.query("UPDATE users SET role='owner' WHERE id=$1 RETURNING *",[u.rows[0].id]);
  }
 const token=signToken({id:u.rows[0].id,email:u.rows[0].email,role:u.rows[0].role,provider:'google'});setSession(res,token);await log(`oauth_${provider}`,email);return res.writeHead(302,{Location:`${baseUrl(req)}/?login=success`}).end();}

module.exports = async (req,res) => {
 try{
  const route=routeOf(req);
  if(route==='catalog' && req.method==='GET') return catalog(res);
  if(route==='me' && req.method==='GET') return me(req,res);
  if(route==='login' && req.method==='POST') return loginRegister(req,res,false);
  if(route==='register' && req.method==='POST') return loginRegister(req,res,true);
  if(route==='logout' && req.method==='POST'){ res.setHeader('Set-Cookie','kaneki_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'); return ok(res,{ok:true}); }
  if(route==='cart' && req.method==='POST') return cart(req,res);
  if(route==='orders' && req.method==='POST') return orders(req,res);
  if(route==='my-orders' && req.method==='GET') return myOrders(req,res);
  if(route==='tickets' && (req.method==='GET'||req.method==='POST')) return tickets(req,res);
  if(route==='tickets/reply' && req.method==='POST') return ticketReply(req,res);
  if(route==='chat/general' && (req.method==='GET'||req.method==='POST')) return chatGeneral(req,res);
  if(route==='reviews' && (req.method==='GET'||req.method==='POST')) return reviews(req,res);
  if(route==='roblox/lookup' && req.method==='GET') return robloxLookup(req,res);
  if(route==='admin/tickets' && req.method==='GET') return adminTickets(req,res);
  if(route==='admin/roles' && req.method==='POST') return adminRoles(req,res);
  if(route==='admin/summary' && req.method==='GET') return adminSummary(req,res);
  if(route==='admin/product' && req.method==='POST') return adminProduct(req,res,false);
  if(route==='admin/product-delete' && req.method==='POST') return adminProduct(req,res,true);
  if(route==='site-settings' && req.method==='GET') return siteSettings(res);
  if(route==='admin/settings' && req.method==='POST') return adminSettings(req,res);
  const m=route.match(/^oauth\/(google|discord)(?:\/callback)?$/); if(m){const provider=m[1];return route.endsWith('/callback')?oauthCallback(req,res,provider):oauthStart(req,res,provider);}
  return fail(res,404,'Rota da API não encontrada.');
 }catch(e){console.error(e);return fail(res,500,e.message||'Erro interno do servidor.');}
};
